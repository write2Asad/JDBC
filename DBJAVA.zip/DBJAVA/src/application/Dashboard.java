package application;
import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.*;

public class Dashboard extends Application {

	private static final String DB_URL = "jdbc:sqlite:student.db";
	private TableView<Student> table = new TableView<>();
    private ObservableList<Student> data = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Student Information");

        // Title
        Text sceneTitle = new Text("Student Information");
        sceneTitle.setFont(Font.font(20));

        // Table setup
        TableColumn<Student, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Student, Integer> ageColumn = new TableColumn<>("Age");
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));

        TableColumn<Student, String> gradeColumn = new TableColumn<>("Grade");
        gradeColumn.setCellValueFactory(new PropertyValueFactory<>("grade"));

        TableColumn<Student, Void> actionsColumn = new TableColumn<>("Actions");
        actionsColumn.setCellFactory(col -> new TableCell<Student, Void>() {
            private final Button deleteBtn = new Button("Delete");
            private final Button updateBtn = new Button("Update");

            {

                deleteBtn.setOnAction(event -> {
                    Student student = getTableView().getItems().get(getIndex());
                    DeleteStudent.delete(student.getId());
                    loadData(); // Reload the data to reflect the change in the UI
                });
                
                
                updateBtn.setOnAction(event -> {
                    Student selectedStudent = getTableView().getItems().get(getIndex());
                    UpdateStudentForm.display(selectedStudent);
                    loadData(); // This method should refresh the TableView
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox container = new HBox(updateBtn, deleteBtn);
                    container.setSpacing(10);
                    setGraphic(container);
                }
            }
        });

        table.getColumns().addAll(nameColumn, ageColumn, gradeColumn, actionsColumn);

        // Load data
        loadData();

        // Insert button
        Button insertBtn = new Button("Insert New Student");
//        insertBtn.setOnAction(event -> {
//            System.out.println("Insertion Button");
//        });
        insertBtn.setOnAction(event -> {
            InsertStudentForm.display();
            loadData(); // Assuming loadData() refreshes the data in your TableView
        });


        // Layout setup
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.getChildren().addAll(sceneTitle, table, insertBtn);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadData() {
        // Load data from the database into the `data` ObservableList
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM student")) {
        	while (rs.next()) {
        	    data.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age"), rs.getString("grade")));
        	}

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        table.setItems(data);
    }

    public static void main(String[] args) {
        launch(args);
    }

    // Dummy Student class for demonstration
    public static class Student {
    	private final SimpleIntegerProperty id;
        private final SimpleStringProperty name;
        private final SimpleIntegerProperty age;
        private final SimpleStringProperty grade;

        Student(int id, String name, int age, String grade) {
        	this.id = new SimpleIntegerProperty(id);
            this.name = new SimpleStringProperty(name);
            this.age = new SimpleIntegerProperty(age);
            this.grade = new SimpleStringProperty(grade);
        }
        public int getId() {return id.get();}
        public void setId(int id) {this.id.set(id);}
        public String getName() { return name.get(); }
        public void setName(String fName) { name.set(fName); }
        public int getAge() { return age.get(); }
        public void setAge(int fAge) { age.set(fAge); }
        public String getGrade() { return grade.get(); }
        public void setGrade(String fGrade) { grade.set(fGrade); }
    }
}
