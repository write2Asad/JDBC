package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertStudentForm {
	private static final String DB_URL = "jdbc:sqlite:student.db";
	
    public static void display() {
        Stage window = new Stage();

        // Block events to other windows
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Insert New Student");
        window.setMinWidth(300);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));

        // Name input
        Label nameLabel = new Label("Name:");
        TextField nameInput = new TextField();

        // Age input
        Label ageLabel = new Label("Age:");
        TextField ageInput = new TextField();

        // Grade input
        Label gradeLabel = new Label("Grade:");
        TextField gradeInput = new TextField();

        // Insert button
        Button insertButton = new Button("Insert");
        insertButton.setOnAction(e -> {
            insertStudent(nameInput.getText(), Integer.parseInt(ageInput.getText()), gradeInput.getText());
            window.close(); // Close the window after insertion
        });

        grid.add(nameLabel, 0, 0);
        grid.add(nameInput, 1, 0);
        grid.add(ageLabel, 0, 1);
        grid.add(ageInput, 1, 1);
        grid.add(gradeLabel, 0, 2);
        grid.add(gradeInput, 1, 2);
        grid.add(insertButton, 1, 3);

        Scene scene = new Scene(grid);
        window.setScene(scene);
        window.showAndWait();
    }
    
    private static void insertStudent(String name, int age, String grade) {
        String sql = "INSERT INTO student(name, age, grade) VALUES(?,?,?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, grade);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error inserting student: " + e.getMessage());
        }
    }
}
