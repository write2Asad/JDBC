package application;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;

public class DeleteStudent {
	private static final String DB_URL = "jdbc:sqlite:student.db";
    
    public static void delete(int studentId) {
        // Show confirmation dialog
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Delete Student");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText("Are you sure you want to delete this student?");

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // If user confirmed, proceed with deletion
            String sql = "DELETE FROM student WHERE id = ?";

            try (Connection conn = DriverManager.getConnection(DB_URL);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, studentId);
                int affectedRows = pstmt.executeUpdate();

                if (affectedRows > 0) {
                    // Show success message
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Success");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("The student has been successfully deleted.");
                    successAlert.showAndWait();
                }
            } catch (SQLException e) {
                System.err.println("Error deleting student: " + e.getMessage());
                // Here, you could also show an error message to the user if needed.
            }
        }
    }

}
