package application;
	
import javafx.application.Application;

import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.*;

public class Main extends Application {
	
    private static final String DB_URL = "jdbc:sqlite:student.db";

	@Override
	public void start(Stage primaryStage) {
		
		primaryStage.setTitle("Login / Registration");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Label userNameLabel = new Label("Username:");
        grid.add(userNameLabel, 0, 1);

        TextField userNameTextField = new TextField();
        grid.add(userNameTextField, 1, 1);

        Label passwordLabel = new Label("Password:");
        grid.add(passwordLabel, 0, 2);

        PasswordField passwordField = new PasswordField();
        grid.add(passwordField, 1, 2);

        Button loginButton = new Button("Login");
        grid.add(loginButton, 0, 3);

        Button registerButton = new Button("Register");
        grid.add(registerButton, 1, 3);

        final Text actionText = new Text();
        grid.add(actionText, 1, 4);
        
        loginButton.setOnAction(e -> {
        	  if (authenticateUser(userNameTextField.getText(), passwordField.getText())) {
              	Platform.runLater(() -> {
              	    new Dashboard().start(new Stage());
              		System.out.println("User Authenticated");
              	});
              
              } else {
                  showAlert(Alert.AlertType.ERROR, "Login Failed", "Incorrect username or password.");
              }
        });
        
        registerButton.setOnAction(e -> {
        	 if (registerUser(userNameTextField.getText(), passwordField.getText())) {
                 actionText.setText("Registration successful.");
             } else {
                 showAlert(Alert.AlertType.ERROR, "Registration Failed", "Could not register user. Maybe the username is already taken.");
             }
        });
        
        
        Scene scene = new Scene(grid, 300, 275);
        primaryStage.setScene(scene);
        primaryStage.show();
		
    }
	
	private boolean registerUser(String username, String password) {
        String sql = "INSERT INTO users(username, password) VALUES(?,?)";

        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return false;
        }
    }
	
	  private boolean authenticateUser(String username, String password) {
	        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

	        try (Connection conn = DriverManager.getConnection(DB_URL);
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            pstmt.setString(1, username);
	            pstmt.setString(2, password);

	            ResultSet rs = pstmt.executeQuery();

	            return rs.next();
	        } catch (SQLException e) {
	            System.err.println(e.getMessage());
	            return false;
	        }
	    }

	   private void showAlert(Alert.AlertType alertType, String title, String message) {
	        Alert alert = new Alert(alertType);
	        alert.setTitle(title);
	        alert.setHeaderText(null);
	        alert.setContentText(message);
	        alert.showAndWait();
	    }
	
	public static void main(String[] args) {
		launch(args);
	}
}
